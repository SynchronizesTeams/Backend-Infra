import{p as s}from"#entry";const e=s("/images/penus/Gedung_Utama.webp");export{e as _};
