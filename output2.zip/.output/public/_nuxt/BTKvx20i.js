import{p as s}from"#entry";const t=s("/images/pekanit.jpg");export{t as _};
