const sources = [
    {
        "context": {
            "name": "sitemap:urls",
            "description": "Set with the `sitemap.urls` config."
        },
        "urls": [],
        "sourceType": "user"
    },
    {
        "context": {
            "name": "nuxt:pages",
            "description": "Generated from your static page files.",
            "tips": [
                "Can be disabled with `{ excludeAppSources: ['nuxt:pages'] }`."
            ]
        },
        "urls": [
            {
                "loc": "/"
            },
            {
                "loc": "/news"
            },
            {
                "loc": "/forums"
            },
            {
                "loc": "/Galery"
            },
            {
                "loc": "/portals"
            },
            {
                "loc": "/profile"
            },
            {
                "loc": "/dashboard/links"
            },
            {
                "loc": "/achievements"
            },
            {
                "loc": "/test-notifications"
            }
        ],
        "sourceType": "app"
    }
];

export { sources };
//# sourceMappingURL=global-sources.mjs.map
